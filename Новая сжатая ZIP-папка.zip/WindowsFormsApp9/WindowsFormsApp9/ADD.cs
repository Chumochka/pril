﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp9
{
    public partial class ADD : Form
    {
        public ADD()
        {
            InitializeComponent();
            using (SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-8HTSRKG\SQLEXPRESS;Initial Catalog=test;Integrated Security=True"))
            {
                Con.Open();
                string query = "SELECT * FROM Gender";
                SqlCommand command = new SqlCommand(query, Con);
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                comboBox1.DataSource = dt;
                comboBox1.DisplayMember = "Name";
                Con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(tb_fam.Text!="" && tb_nam.Text!="" && tb_em.Text!="" && tb_ot.Text!="" && tb_tel.Text!="")
            {
                int n = comboBox1.SelectedIndex + 1;
                using (SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-8HTSRKG\SQLEXPRESS;Initial Catalog=test;Integrated Security=True"))
                {
                    Con.Open();
                    string query = "INSERT INTO Client (FirstName,LastName,Patronymic,Birthday,RegistrationDate,Email,Phone,GenderCode,PhotoPath) VALUES ('"+tb_fam.Text+"','"+tb_nam.Text+"','"+tb_ot.Text+"','"+dtp_birth.Value+"','"+DateTime.Now+"','"+tb_em.Text+"','"+tb_tel.Text+"','"+n+"','')";
                    SqlCommand command = new SqlCommand(query, Con);
                    command.ExecuteNonQuery();
                    Con.Close();
                }
                this.Close();
            }
        }
    }
}
