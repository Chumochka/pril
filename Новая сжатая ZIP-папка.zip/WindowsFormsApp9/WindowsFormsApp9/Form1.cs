﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApp9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-8HTSRKG\SQLEXPRESS;Initial Catalog=test;Integrated Security=True"))
            {
                Con.Open();
                string query = "SELECT ID,FirstName AS Фамилия,LastName AS Имя,Patronymic AS Отчество,Birthday AS [Дата рождения],Gender.Name AS Пол,RegistrationDate AS [Дата регистрации],Email,Phone AS Телефон,PhotoPath AS Фото FROM Client JOIN Gender ON GenderCode=Gender.Code";
                SqlCommand command = new SqlCommand(query, Con);
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                Con.Close();
                if (dt.Rows.Count != 0)
                {
                    dgv_Clients.DataSource = dt;
                    dgv_Clients.Update();
                }
            }
        }

        private void tb_Search1_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-8HTSRKG\SQLEXPRESS;Initial Catalog=test;Integrated Security=True"))
            {
                Con.Open();
                string query = "SELECT ID,FirstName AS Фамилия,LastName AS Имя,Patronymic AS Отчество,Birthday AS [Дата рождения],Gender.Name AS Пол,RegistrationDate AS [Дата регистрации],Email,Phone AS Телефон,PhotoPath AS Фото FROM Client JOIN Gender ON GenderCode=Gender.Code WHERE FirstName LIKE '%"+tb_Search1.Text+"%' and Email LIKE '%"+tb_Search3.Text+"%' and Phone Like '%"+tb_Search2.Text+"%'";
                SqlCommand command = new SqlCommand(query, Con);
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                Con.Close();
                if (dt.Rows.Count != 0)
                {
                    dgv_Clients.DataSource = dt;
                    dgv_Clients.Update();
                }
            }
        }

        private void tb_Search2_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-8HTSRKG\SQLEXPRESS;Initial Catalog=test;Integrated Security=True"))
            {
                Con.Open();
                string query = "SELECT ID,FirstName AS Фамилия,LastName AS Имя,Patronymic AS Отчество,Birthday AS [Дата рождения],Gender.Name AS Пол,RegistrationDate AS [Дата регистрации],Email,Phone AS Телефон,PhotoPath AS Фото FROM Client JOIN Gender ON GenderCode=Gender.Code WHERE FirstName LIKE '%" + tb_Search1.Text + "%' and Email LIKE '%" + tb_Search3.Text + "%' and Phone Like '%" + tb_Search2.Text + "%'";
                SqlCommand command = new SqlCommand(query, Con);
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                Con.Close();
                if (dt.Rows.Count != 0)
                {
                    dgv_Clients.DataSource = dt;
                    dgv_Clients.Update();
                }
            }
        }

        private void tb_Search3_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-8HTSRKG\SQLEXPRESS;Initial Catalog=test;Integrated Security=True"))
            {
                Con.Open();
                string query = "SELECT ID,FirstName AS Фамилия,LastName AS Имя,Patronymic AS Отчество,Birthday AS [Дата рождения],Gender.Name AS Пол,RegistrationDate AS [Дата регистрации],Email,Phone AS Телефон,PhotoPath AS Фото FROM Client JOIN Gender ON GenderCode=Gender.Code WHERE FirstName LIKE '%" + tb_Search1.Text + "%' and Email LIKE '%" + tb_Search3.Text + "%' and Phone Like '%" + tb_Search2.Text + "%'";
                SqlCommand command = new SqlCommand(query, Con);
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                Con.Close();
                if (dt.Rows.Count != 0)
                {
                    dgv_Clients.DataSource = dt;
                    dgv_Clients.Update();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ADD form = new ADD();
            form.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Delete form = new Delete();
            form.Show();
        }
    }
}